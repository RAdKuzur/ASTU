﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LAB_1_SADCHIKOV
{
    public static class Var {
        public static int flag = 0;

    }
    internal class Class1
    {
    }
}
